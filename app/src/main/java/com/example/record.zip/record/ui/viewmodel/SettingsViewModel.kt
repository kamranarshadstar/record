package com.example.record.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.record.RecordApp
import com.example.record.data.repository.UserPreferences
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as RecordApp).userPreferencesRepository

    val preferences: StateFlow<UserPreferences?> = repository.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    // ADD THIS FUNCTION
    fun updateMaxConcurrentUploads(count: Int) {
        viewModelScope.launch {
            repository.updateMaxConcurrentUploads(count)
        }
    }

    fun updateChunkInterval(minutes: Int) {
        viewModelScope.launch {
            repository.updateChunkInterval(minutes)
        }
    }

    fun updateMaxStorage(mb: Int) {
        viewModelScope.launch {
            repository.updateMaxStorage(mb)
        }
    }

    fun updateUploadServerUrl(url: String) {
        viewModelScope.launch {
            repository.updateUploadServerUrl(url)
        }
    }

    fun updateClientId(clientId: String) {
        viewModelScope.launch {
            repository.updateClientId(clientId)
        }
    }

    fun updateAuthToken(token: String) {
        viewModelScope.launch {
            repository.updateAuthToken(token)
        }
    }
}