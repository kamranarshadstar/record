package com.example.record.audio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log

/**
 * Handles playback of recorded audio files.
 * 
 * Supports:
 * - Playing WAV files from file path
 * - Pause/resume/stop controls
 * - Seeking to specific positions
 * - Completion callbacks
 */
class AudioPlayer(private val context: Context) {
    companion object {
        private const val TAG = "AudioPlayer"
    }

    private var mediaPlayer: MediaPlayer? = null

    val isPlaying: Boolean get() = mediaPlayer?.isPlaying == true
    val currentPosition: Int get() = try {
        mediaPlayer?.currentPosition ?: 0
    } catch (e: Exception) {
        Log.w(TAG, "Error getting current position", e)
        0
    }
    val duration: Int get() = try {
        mediaPlayer?.duration ?: 0
    } catch (e: Exception) {
        Log.w(TAG, "Error getting duration", e)
        0
    }

    /**
     * Play an audio file from file path.
     * 
     * @param filePath Absolute path to audio file or valid URI
     * @param onCompletion Callback when playback completes
     */
    fun playFile(filePath: String, onCompletion: () -> Unit) {
        stop()
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, Uri.parse(filePath))
                prepare()
                setOnCompletionListener {
                    Log.d(TAG, "Playback completed")
                    onCompletion()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "Playback error: what=$what, extra=$extra")
                    onCompletion() // Treat error as completion
                    true
                }
                start()
                Log.d(TAG, "Started playing: $filePath (duration: ${duration}ms)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing file: $filePath", e)
            onCompletion()
        }
    }

    /**
     * Pause playback without releasing resources.
     */
    fun pause() {
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
                Log.d(TAG, "Paused at: ${mediaPlayer?.currentPosition}ms")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing playback", e)
        }
    }

    /**
     * Resume playback from current position.
     */
    fun resume() {
        try {
            if (mediaPlayer?.isPlaying == false) {
                mediaPlayer?.start()
                Log.d(TAG, "Resumed from: ${mediaPlayer?.currentPosition}ms")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error resuming playback", e)
        }
    }

    /**
     * Seek to specific position in playback.
     * 
     * @param positionMs Position in milliseconds
     */
    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.seekTo(positionMs)
            Log.d(TAG, "Seeked to: ${positionMs}ms")
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking to $positionMs", e)
        }
    }

    /**
     * Stop playback and release resources.
     */
    fun stop() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer!!.isPlaying) {
                    mediaPlayer!!.stop()
                }
                mediaPlayer!!.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping playback", e)
        } finally {
            mediaPlayer = null
        }
    }
}