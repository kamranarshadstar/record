package com.example.record.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.record.data.repository.UserPreferences
import com.example.record.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {

    val prefs by viewModel.preferences.collectAsStateWithLifecycle()

    SettingsContent(
        preferences = prefs,
        onUpdateChunkInterval = viewModel::updateChunkInterval,
        onUpdateMaxStorage = viewModel::updateMaxStorage,
        onUpdateUploadServerUrl = viewModel::updateUploadServerUrl,
        onUpdateClientId = viewModel::updateClientId,
        onUpdateAuthToken = viewModel::updateAuthToken,
        onUpdateMaxConcurrentUploads = viewModel::updateMaxConcurrentUploads
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsContent(
    preferences: UserPreferences?,
    onUpdateChunkInterval: (Int) -> Unit,
    onUpdateMaxStorage: (Int) -> Unit,
    onUpdateUploadServerUrl: (String) -> Unit,
    onUpdateClientId: (String) -> Unit,
    onUpdateAuthToken: (String) -> Unit,
    onUpdateMaxConcurrentUploads: (Int) -> Unit,
    modifier: Modifier = Modifier
) {

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Settings") })
        }
    ) { padding ->

        if (preferences == null) {

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }

        } else {

            val p = preferences

            // TEXT STATES
            var uploadUrl by remember(p.uploadServerUrl) { mutableStateOf(p.uploadServerUrl) }
            var clientId by remember(p.clientId) { mutableStateOf(p.clientId) }
            var authToken by remember(p.authToken) { mutableStateOf(p.authToken) }

            // SLIDER STATES (FIXED)
            var chunk by remember(p.chunkIntervalMinutes) {
                mutableStateOf(p.chunkIntervalMinutes.toFloat())
            }

            var uploads by remember(p.maxConcurrentUploads) {
                mutableStateOf(p.maxConcurrentUploads.toFloat())
            }

            var storage by remember(p.maxStorageMb) {
                mutableStateOf(p.maxStorageMb.toFloat())
            }

            Column(
                modifier = modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                SectionTitle("UPLOAD SETTINGS")

                SettingCard(
                    title = "Chunk Duration",
                    description = "Splits audio into smaller files.",
                    value = "${chunk.toInt()} min"
                ) {
                    Slider(
                        value = chunk,
                        onValueChange = { chunk = it },
                        onValueChangeFinished = {
                            onUpdateChunkInterval(chunk.toInt())
                        },
                        valueRange = 1f..30f,
                        steps = 28
                    )
                }

                SettingCard(
                    title = "Concurrent Uploads",
                    description = "Number of uploads running at the same time.",
                    value = "${uploads.toInt()}"
                ) {
                    Slider(
                        value = uploads,
                        onValueChange = { uploads = it },
                        onValueChangeFinished = {
                            onUpdateMaxConcurrentUploads(uploads.toInt())
                        },
                        valueRange = 1f..10f,
                        steps = 8
                    )
                }

                SectionTitle("STORAGE")

                SettingCard(
                    title = "Max Storage",
                    description = "Old recordings are deleted when limit is reached.",
                    value = "${storage.toInt()} MB"
                ) {
                    Slider(
                        value = storage,
                        onValueChange = { storage = it },
                        onValueChangeFinished = {
                            onUpdateMaxStorage(storage.toInt())
                        },
                        valueRange = 100f..10000f,
                        steps = 99
                    )
                }

                SectionTitle("SERVER")

                SettingTextFieldCard(
                    title = "Upload Server URL",
                    description = "Server endpoint for uploads.",
                    value = uploadUrl,
                    onValueChange = { uploadUrl = it },
                    buttonText = "Save URL",
                    onSave = { onUpdateUploadServerUrl(uploadUrl.trim()) },
                    leadingIcon = { Icon(Icons.Outlined.Link, null) }
                )

                SettingTextFieldCard(
                    title = "Client ID",
                    description = "Unique identifier for this device.",
                    value = clientId,
                    onValueChange = { clientId = it },
                    buttonText = "Save Client ID",
                    onSave = { onUpdateClientId(clientId.trim()) },
                    leadingIcon = { Icon(Icons.Outlined.CloudUpload, null) }
                )

                SettingTextFieldCard(
                    title = "Auth Token",
                    description = "Authentication token for secure uploads.",
                    value = authToken,
                    onValueChange = { authToken = it },
                    buttonText = "Save Token",
                    onSave = { onUpdateAuthToken(authToken.trim()) },
                    leadingIcon = { Icon(Icons.Outlined.Lock, null) },
                    isPassword = true
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

/* ---------------- UI COMPONENTS ---------------- */

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun SettingCard(
    title: String,
    description: String,
    value: String,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)

                Text(
                    value,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(Modifier.height(6.dp))

            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(16.dp))

            content()
        }
    }
}

@Composable
fun SettingTextFieldCard(
    title: String,
    description: String,
    value: String,
    onValueChange: (String) -> Unit,
    buttonText: String,
    onSave: () -> Unit,
    leadingIcon: @Composable () -> Unit,
    isPassword: Boolean = false
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {

            Text(title, style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(6.dp))

            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                leadingIcon = leadingIcon,
                visualTransformation =
                    if (isPassword) PasswordVisualTransformation()
                    else VisualTransformation.None
            )

            Spacer(Modifier.height(12.dp))

            FilledTonalButton(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(buttonText)
            }
        }
    }
}