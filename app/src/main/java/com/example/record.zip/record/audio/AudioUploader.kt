package com.example.record.audio

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody

/**
 * Audio uploader that deletes the local file ONLY after a successful server response.
 */
class AudioUploader(
    private val baseUrl: String = "https://your-upload-server.com/api/upload",
    private val clientId: String = "android-device-001",
    private val authToken: String = "DEVICE_TOKEN_ABC123"
) {

    companion object {
        private const val TAG = "AudioUploader"
        private const val MAX_RETRIES = 3
        private const val INITIAL_BACKOFF_MS = 1_000L
    }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    suspend fun uploadChunk(
        filePath: String,
        fileName: String,
        startTime: Long,
        endTime: Long,
        duration: Long
    ) = withContext(Dispatchers.IO) {

        val file = File(filePath)

        if (!file.exists()) {
            Log.e(TAG, "File not found: $filePath")
            return@withContext
        }

        var attempt = 0
        var backoff = INITIAL_BACKOFF_MS

        while (attempt < MAX_RETRIES) {
            try {
                // 1. Attempt the upload
                uploadOnce(file, fileName, startTime, endTime, duration)

                // 2. If uploadOnce didn't throw an exception, it was successful.
                // Now we delete the local file.
                if (file.exists()) {
                    val wasDeleted = file.delete()
                    if (wasDeleted) {
                        Log.d(TAG, "Successfully uploaded and REMOVED from device: ${file.name}")
                    } else {
                        Log.e(TAG, "Uploaded successfully, but failed to delete local file.")
                    }
                }

                // Exit the loop and function
                return@withContext

            } catch (e: Exception) {
                attempt++
                Log.e(TAG, "Upload failed (attempt $attempt/$MAX_RETRIES): ${e.message}")

                if (attempt >= MAX_RETRIES) {
                    // Out of retries, the file stays on the device for the next session
                    throw e
                }

                delay(backoff)
                backoff *= 2
            }
        }
    }

    private fun uploadOnce(
        file: File,
        fileName: String,
        startTime: Long,
        endTime: Long,
        duration: Long
    ) {
        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                name = "file",
                filename = "$fileName.wav",
                body = file.asRequestBody("audio/wav".toMediaType())
            )
            .addFormDataPart("startTime", startTime.toString())
            .addFormDataPart("endTime", endTime.toString())
            .addFormDataPart("duration", duration.toString())
            .build()

        val request = Request.Builder()
            .url(baseUrl)
            .post(requestBody)
            // Including your original headers just in case your server logs them
            .addHeader("X-Client-Id", clientId)
            .addHeader("X-Auth-Token", authToken)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Server returned error code: ${response.code}")
            }
        }
    }
}